
"use client";

import { useState } from "react";
import {
  ArrowRight,
  Mail,
  MessageSquare,
  Send,
  CheckCircle,
} from "lucide-react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    // Frontend demonstration only.
    // Backend/email integration will be added later.
    setSubmitted(true);
  }

  return (
    <section id="contact" className="section contact-section">
      <div className="container contact-container">

        {/* LEFT SIDE - CONTACT INTRODUCTION */}

        <div className="contact-content">
          <span className="section-label">
            05 — LET'S CONNECT
          </span>

          <h2>
            Simplify Work.
            <br />
            <span>Amplify Growth.</span>
          </h2>

          <p>
            A practical conversation starts with one business
            challenge. Tell us what you want to improve, and
            let's explore a suitable solution.
          </p>

          <div className="contact-detail">
            <div className="contact-detail-icon">
              <Mail size={21} />
            </div>

            <div>
              <strong>Start a conversation</strong>
              <span>
                Share your business enquiry through our form.
              </span>
            </div>
          </div>

          <div className="contact-detail">
            <div className="contact-detail-icon">
              <MessageSquare size={21} />
            </div>

            <div>
              <strong>Tell us your challenge</strong>
              <span>
                Describe the process or problem you want to improve.
              </span>
            </div>
          </div>
        </div>

        {/* RIGHT SIDE - ENQUIRY FORM */}

        <div className="contact-form-card">
          <h3>Send us an enquiry</h3>

          <p>
            Let's start with a little information about your needs.
          </p>

          {submitted ? (
            <div className="form-notice" role="status">
              <CheckCircle size={30} />

              <strong>Form interface tested!</strong>

              <span>
                This is currently a frontend demonstration.
                Your enquiry has not been emailed or stored.
                Backend integration will be added later.
              </span>

              <button
                type="button"
                className="text-link"
                onClick={() => setSubmitted(false)}
              >
                Submit another enquiry
                <ArrowRight size={16} />
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>

              <div className="form-row">
                <label>
                  Your name

                  <input
                    name="name"
                    type="text"
                    placeholder="Enter your name"
                    autoComplete="name"
                    required
                  />
                </label>

                <label>
                  Email address

                  <input
                    name="email"
                    type="email"
                    placeholder="you@example.com"
                    autoComplete="email"
                    required
                  />
                </label>
              </div>

              <label>
                What service are you interested in?

                <select
                  name="service"
                  defaultValue=""
                  required
                >
                  <option value="" disabled>
                    Select a service
                  </option>

                  <option value="Automation">
                    Automation
                  </option>

                  <option value="Data and Business Intelligence">
                    Data & Business Intelligence
                  </option>

                  <option value="Digital Experiences">
                    Digital Experiences
                  </option>

                  <option value="Other">
                    Other enquiry
                  </option>
                </select>
              </label>

              <label>
                Tell us about your business challenge

                <textarea
                  name="message"
                  rows={4}
                  placeholder="How can we help your business?"
                  required
                />
              </label>

              <button
                type="submit"
                className="btn btn-primary form-submit"
              >
                Send Enquiry
                <ArrowRight size={18} />
              </button>

            </form>
          )}
        </div>

      </div>
    </section>
  );
}
