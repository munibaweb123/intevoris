
import {
  Search,
  ClipboardList,
  Code2,
  ShieldCheck,
  Headset,
  ArrowRight,
} from "lucide-react";

const processSteps = [
  {
    number: "01",
    icon: Search,
    title: "Understand",
    description:
      "We learn about your business, understand your challenges and identify opportunities for improvement.",
    detail: "Discover your needs",
  },
  {
    number: "02",
    icon: ClipboardList,
    title: "Define",
    description:
      "We define the project scope, outline requirements and identify the right approach for your goals.",
    detail: "Plan the right solution",
  },
  {
    number: "03",
    icon: Code2,
    title: "Build",
    description:
      "We develop practical automation, AI and digital solutions designed around your business needs.",
    detail: "Turn ideas into solutions",
  },
  {
    number: "04",
    icon: ShieldCheck,
    title: "Validate",
    description:
      "We review and test the solution to check functionality, reliability and alignment with requirements.",
    detail: "Test and improve",
  },
  {
    number: "05",
    icon: Headset,
    title: "Deliver & Support",
    description:
      "We deliver the solution and provide support to help you move forward with confidence.",
    detail: "Launch and support",
  },
];

export default function Process() {
  return (
    <section id="process" className="section process-section">
      <div className="container">

        {/* SECTION HEADING */}

        <div className="section-heading process-heading">
          <span className="section-label">
            04 — HOW WE WORK
          </span>

          <h2>
            A clear process.
            <br />
            <span>Meaningful progress.</span>
          </h2>

          <p>
            Every successful solution starts with understanding
            the problem. Our structured approach takes your
            ideas from initial discovery to delivery and support.
          </p>
        </div>

        {/* PROCESS STEPS */}

        <div className="process-timeline">
          {processSteps.map((step, index) => {
            const Icon = step.icon;

            return (
              <article
                className="process-step"
                key={step.number}
              >
                <div className="process-step-top">
                  <span className="process-number">
                    {step.number}
                  </span>

                  <div className="process-icon">
                    <Icon size={25} />
                  </div>
                </div>

                <div className="process-step-content">
                  <span className="process-detail">
                    {step.detail}
                  </span>

                  <h3>{step.title}</h3>

                  <p>{step.description}</p>
                </div>

                {index !== processSteps.length - 1 && (
                  <div className="process-arrow">
                    <ArrowRight size={18} />
                  </div>
                )}
              </article>
            );
          })}
        </div>

        {/* BOTTOM CTA */}

        <div className="process-cta">
          <div>
            <span>READY TO GET STARTED?</span>
            <h3>Let's turn your ideas into progress.</h3>
          </div>

          <a href="#contact" className="btn btn-primary">
            Start a Conversation
            <ArrowRight size={18} />
          </a>
        </div>

      </div>
    </section>
  );
}
