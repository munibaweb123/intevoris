
import { ArrowUpRight, ArrowUp } from "lucide-react";
import { FaLinkedinIn, FaFacebookF } from "react-icons/fa";

const footerLinks = {
  explore: [
    { label: "Home", href: "#home" },
    { label: "About Us", href: "#about" },
    { label: "Our Services", href: "#services" },
    { label: "Our Process", href: "#process" },
  ],

  services: [
    { label: "Automation", href: "#services" },
    { label: "Data & Business Intelligence", href: "#services" },
    { label: "Digital Experiences", href: "#services" },
    { label: "AI Solutions", href: "#solutions" },
  ],
};

export default function Footer() {


  return (
    <footer className="footer">
      <div className="container">

        <div className="footer-main">

          {/* COMPANY BRAND */}
          <div className="footer-brand">
            <a href="#home" className="brand footer-logo">
              <span className="brand-symbol">I</span>

              <span>
                <strong>INTEVORIS</strong>
                <small>AI SOLUTIONS</small>
              </span>
            </a>

            <p>
              Technology that fits the way you work.
              Simplifying operations and supporting
              business growth through intelligent
              digital solutions.
            </p>

            <a href="#contact" className="footer-contact-link">
              Let's work together
              <ArrowUpRight size={17} />
            </a>

            {/* SOCIAL MEDIA ICONS */}
            <div className="footer-socials">
              <a
                href="https://www.linkedin.com/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                title="LinkedIn"
              >
                <FaLinkedinIn />
              </a>

              <a
                href="https://www.facebook.com/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                title="Facebook"
              >
                <FaFacebookF />
              </a>
            </div>
          </div>

          {/* EXPLORE LINKS */}
          <div className="footer-column">
            <h4>Explore</h4>

            {footerLinks.explore.map((link) => (
              <a href={link.href} key={link.label}>
                {link.label}
              </a>
            ))}
          </div>

          {/* SERVICES LINKS */}
          <div className="footer-column">
            <h4>Our Services</h4>

            {footerLinks.services.map((link) => (
              <a href={link.href} key={link.label}>
                {link.label}
              </a>
            ))}
          </div>

          {/* CONTACT */}
          <div className="footer-column footer-connect">
            <h4>Get in Touch</h4>

            <p>
              Have a business challenge?
              Let's explore how technology can help.
            </p>

            <a href="#contact" className="footer-cta">
              Contact Us
              <ArrowUpRight size={16} />
            </a>
          </div>

        </div>

        {/* FOOTER BOTTOM */}
        <div className="footer-bottom">
          <p>
            © 2026 Intevoris AI Solutions.
            All rights reserved.
          </p>

          <span className="footer-tagline">
            Simplify Work. Amplify Growth.
          </span>

          <a href="#home" className="back-to-top">
            Back to top
            <ArrowUp size={15} />
          </a>
        </div>

      </div>
    </footer>
  );
}
