
import {
  Workflow,
  Bot,
  FileText,
  BarChart3,
  Database,
  ChartNoAxesCombined,
  Globe,
  ShoppingCart,
  MonitorSmartphone,
  ArrowUpRight,
} from "lucide-react";

const services = [
  {
    number: "01",
    icon: Workflow,
    title: "Automation",
    description:
      "Simplify repetitive business operations with intelligent automation and connected workflows.",
    features: [
      {
        icon: Workflow,
        title: "Business Workflow Automation",
        description:
          "Connect everyday business tasks and streamline repetitive processes.",
      },
      {
        icon: Bot,
        title: "Robotic Process Automation",
        description:
          "Use software robots to handle repetitive, rule-based activities.",
      },
      {
        icon: FileText,
        title: "Document Processing",
        description:
          "Automate document handling and information extraction.",
      },
    ],
  },
  {
    number: "02",
    icon: ChartNoAxesCombined,
    title: "Data & Business Intelligence",
    description:
      "Turn business information into organized reports and meaningful insights.",
    features: [
      {
        icon: BarChart3,
        title: "Dashboards & Reporting",
        description:
          "Present important business information through clear dashboards and reports.",
      },
      {
        icon: Database,
        title: "Data Management",
        description:
          "Organize business data to make information easier to access and understand.",
      },
      {
        icon: ChartNoAxesCombined,
        title: "Reconciliation & Validation",
        description:
          "Compare and validate information to support accurate business records.",
      },
    ],
  },
  {
    number: "03",
    icon: MonitorSmartphone,
    title: "Digital Experiences",
    description:
      "Build useful digital experiences that strengthen your online presence and customer interactions.",
    features: [
      {
        icon: Globe,
        title: "Company Websites",
        description:
          "Create professional websites that communicate your brand and services.",
      },
      {
        icon: ShoppingCart,
        title: "E-commerce Stores",
        description:
          "Build online shopping experiences for products and services.",
      },
      {
        icon: Bot,
        title: "AI Assistants",
        description:
          "Create intelligent assistants to support customer interactions.",
      },
    ],
  },
];

export default function Services() {
  return (
    <section id="services" className="section services-section">
      <div className="container">

        {/* SECTION HEADING */}

        <div className="section-heading services-heading">
          <span className="section-label">
            02 — WHAT WE DO
          </span>

          <h2>
            Technology designed
            <br />
            <span>around your business.</span>
          </h2>

          <p>
            From intelligent automation to digital experiences,
            we help businesses simplify operations and make
            technology work for them.
          </p>
        </div>

        {/* SERVICE CARDS */}

        <div className="services-grid">
          {services.map((service) => {
            const MainIcon = service.icon;

            return (
              <article
                className="service-card"
                key={service.number}
              >
                <div className="service-card-header">
                  <span className="service-number">
                    {service.number}
                  </span>

                  <div className="service-main-icon">
                    <MainIcon size={28} />
                  </div>
                </div>

                <h3>{service.title}</h3>

                <p className="service-description">
                  {service.description}
                </p>

                <div className="service-divider" />

                {/* INDIVIDUAL SERVICES */}

                <div className="service-features">
                  {service.features.map((feature) => {
                    const FeatureIcon = feature.icon;

                    return (
                      <div
                        className="service-feature"
                        key={feature.title}
                      >
                        <div className="feature-icon">
                          <FeatureIcon size={19} />
                        </div>

                        <div>
                          <h4>{feature.title}</h4>
                          <p>{feature.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <a href="#contact" className="service-link">
                  Discuss this service
                  <ArrowUpRight size={17} />
                </a>
              </article>
            );
          })}
        </div>

        {/* BOTTOM CTA */}

        <div className="services-bottom">
          <p>
            Not sure which solution fits your business?
          </p>

          <a href="#contact" className="text-link">
            Let's discuss your needs
            <ArrowUpRight size={17} />
          </a>
        </div>

      </div>
    </section>
  );
}
