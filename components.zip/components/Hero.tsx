
import {
  ArrowRight,
  ArrowUpRight,
  Workflow,
  Bot,
  ChartNoAxesCombined,
} from "lucide-react";

const highlights = [
  {
    icon: Workflow,
    title: "Smart Automation",
    description: "Simplify repetitive work",
  },
  {
    icon: Bot,
    title: "AI Assistants",
    description: "Make interactions smarter",
  },
  {
    icon: ChartNoAxesCombined,
    title: "Business Intelligence",
    description: "Turn data into clarity",
  },
];

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="hero-glow hero-glow-one" />
      <div className="hero-glow hero-glow-two" />

      <div className="container hero-container">
        {/* Left side: Main introduction */}
        <div className="hero-content">
          <span className="eyebrow">
            <span className="status-dot" />
            INTELLIGENT DIGITAL SOLUTIONS
          </span>

          <h1>
            Simplify Work.
            <br />
            <span>Amplify Growth.</span>
          </h1>

          <p className="hero-description">
            Technology that fits the way you work.
            We help businesses simplify operations,
            strengthen their digital presence and grow
            through intelligent automation.
          </p>

          <div className="hero-actions">
            <a href="#services" className="btn btn-primary">
              Explore Services <ArrowRight size={18} />
            </a>

            <a href="#contact" className="btn btn-outline">
              Let's Talk <ArrowUpRight size={18} />
            </a>
          </div>

          <div className="hero-note">
            Practical technology. Meaningful progress.
          </div>
        </div>

        {/* Right side: Technology illustration */}
        <div className="hero-visual">
          <div className="visual-orbit orbit-one" />
          <div className="visual-orbit orbit-two" />

          <div className="visual-core">
            <div className="core-icon">
              <Workflow size={44} />
            </div>

            <span>INTELLIGENT</span>
            <strong>WORKFLOWS</strong>
            <small>Connected. Simplified. Smarter.</small>
          </div>

          {highlights.map((item, index) => {
            const Icon = item.icon;

            return (
              <div
                key={item.title}
                className={`floating-card floating-card-${index + 1}`}
              >
                <div className="floating-icon">
                  <Icon size={21} />
                </div>

                <div>
                  <strong>{item.title}</strong>
                  <small>{item.description}</small>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="hero-bottom container">
        <span>01 / INTRODUCTION</span>
        <span>SCROLL TO EXPLORE ↓</span>
      </div>
    </section>
  );
}
