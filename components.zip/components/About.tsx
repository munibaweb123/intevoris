
import { Target, Eye, ArrowUpRight } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="section about-section">
      <div className="container">

        {/* Section Heading */}
        <div className="section-heading">
          <span className="section-label">
            01 — WHO WE ARE
          </span>

          <h2>
            Technology that fits
            <br />
            <span>the way you work.</span>
          </h2>
        </div>

        {/* About Content */}
        <div className="about-grid">

          {/* Company Introduction */}
          <div className="about-intro">
            <span className="mini-line" />

            <h3>
              Intelligent solutions for practical progress.
            </h3>

            <p>
              We help businesses simplify operations,
              strengthen their digital presence and grow
              through intelligent automation.
            </p>

            <a href="#services" className="text-link">
              Discover what we do
              <ArrowUpRight size={17} />
            </a>
          </div>

          {/* Mission Card */}
          <div className="purpose-card">
            <div className="purpose-icon">
              <Target size={26} />
            </div>

            <span>OUR MISSION</span>

            <h3>
              Turn technology into measurable progress.
            </h3>

            <p>
              Practical AI, automation and digital solutions
              that reduce repetitive work, improve efficiency
              and create better customer experiences.
            </p>
          </div>

          {/* Vision Card */}
          <div className="purpose-card vision-card">
            <div className="purpose-icon">
              <Eye size={26} />
            </div>

            <span>OUR VISION</span>

            <h3>
              A trusted partner for digital transformation.
            </h3>

            <p>
              A future where organizations of every size use
              intelligent, connected systems to adapt,
              compete and grow.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
